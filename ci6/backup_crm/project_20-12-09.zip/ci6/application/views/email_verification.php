<!DOCTYPE html>
<html>
<head>
	<title>CRUD</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.css'; ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/toastr.min.css'; ?>">
     
	
</head>
<body>
	<div class="navbar navbar-dark bg-dark">
    <div class="container">
    <a href="#" class="navbar-brand">Email Verification </a>
    </div>


    <div class="container">
      <br/> 
      <h3 align="center"> Complete login register system </h3>
      <br/>
      <?php
       echo $message;
       ?>
    </div>

</body>
</html>