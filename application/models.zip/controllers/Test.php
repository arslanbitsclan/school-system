<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * @package : Aanttech school management system
 * @version : 3.0
 * @developed by : AanttechCoder
 * @support : Aanttechcoder@yahoo.com
 * @author url : http://codecanyon.net/user/AanttechCoder
 * @filename : Accounting.php
 * @copyright : Reserved AanttechCoder Team
 */

class Test extends Admin_Controller
{

	public function __construct()
    {
        parent::__construct();
        $this->load->helper('api');
        $this->load->model('authentication_model');
        $this->load->model('fees_model');

    }

    public function index()
    {
       $response = array();
       $month = date('m', strtotime('2021-may'));
       $year = date('Y', strtotime('2021-may'));

       $this->db->select('fee_vouchers.*');
       $this->db->from('fee_vouchers');
       $this->db->join('fee_voucher_months','fee_voucher_months.fee_voucher_id = fee_vouchers.id');
       $this->db->where('fee_vouchers.student_id', 6);
       $this->db->where('fee_voucher_months.fee_month', $month);
       $this->db->where('fee_voucher_months.fee_year', $year);
       $voucher = $this->db->get()->row();

       if(!empty($voucher)){
        
        $this->db->select('*');
        $this->db->from('fee_voucherables');
        $this->db->where('voucher_id', $voucher->id);
        $voucherables = $this->db->get()->result();

        $total_fine = 0;
        $total_discount = 0;
        $total_paid = 0;
        $total_balance = 0;
        $total_amount = 0;

        if($voucher->carry_balance == 1){
            $previous_balance = previous_balance($voucher->student_id);
        }else{
            $previous_balance = 0;
        }

        $response['fee_heads'] = array();
        foreach ($voucherables as $row) {

            $fee_head = array(
                'fee_head' => $row->fee_head,
                'amount' => $row->amount 
            );

            array_push($response['fee_heads'],$fee_head);

            $type_discount = 0;
            $deposit = $this->fees_model->getStudentFeeDeposit($row->allocation_id, $row->fee_type_id);

            $check_month = check_voucher_month($voucher->id,$row->fee_type_id);
            $discount_info = get_fee_type_discount($voucher->student_id,$row->fee_type_id);

            if(!empty($discount_info)){
                if(!empty($discount_info->discount)){
                    $type_discount = number_format(($discount_info->discount*$check_month), 2, '.', '');

                }else{
                    $total_discount += 0;
                    $type_discount = number_format(0, 2, '.', '');
                }
            }

            $type_fine = number_format(0, 2, '.', '');
            $fine = getBalanceByType($row->allocation_id, $row->fee_type_id,$voucher->voucher_no);

            if($fine > 0){
                $type_fine =  number_format($fine, 2, '.', '');
            }

            $balance = ($row->amount*$check_month - $type_discount) + $type_fine;
            $total_discount += $type_discount;
            $total_fine += $type_fine;
            $total_balance += $balance;
            $total_amount += $row->amount*$check_month;

            if ($balance != 0) {
                $typeData[$row->allocation_id . "|" . $row->fee_type_id] = $row->fee_head;
            }
        }

        $fee_amount = number_format($total_balance-$total_paid+$previous_balance, 2, '.', '');

        $response['total_payable_amount'] = number_format($fee_amount,2, '.', '');
        $response['total_discount'] = number_format($total_discount,2, '.', '');
        $response['total_paid'] = number_format($total_paid,2, '.', '');
        $response['total_fine'] = number_format($total_fine,2, '.', '');
        debug($response);
       }




}
    



}