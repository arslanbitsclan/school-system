<?php

# Version 2.3.0

$lang['auto_backup_options_updated']     = 'Opções atualizadas de Auto backup';
$lang['auto_backup_every']               = 'Criar backup a cada X dias';
$lang['auto_backup_enabled']             = 'Habilitar (Cron Necessário)';
$lang['auto_backup']                     = 'Auto backup';
$lang['backup_delete']                   = 'Backup Deletado';
$lang['backup_success']                  = 'Backup foi feito com sucesso';
$lang['utility_backup']                  = 'Base de dados de Backup';
$lang['utility_create_new_backup_db']    = 'Criar Base de Dados de Backup';
$lang['utility_backup_table_backupname'] = 'Backup';
$lang['utility_backup_table_backupsize'] = 'Tamanho do Backup';
$lang['utility_backup_table_backupdate'] = 'Data';
$lang['utility_db_backup_note']          = 'Nota: Devido ao tempo de execução limitado e memória disponível para o PHP, o backup de grandes bases de dados pode não ser possível. Se seu banco de dados é muito grande você pode precisar de backup diretamente do seu servidor SQL via linha de comando, ou ter o seu administrador do servidor para fazê-lo para você, se você não tiver os privilégios de root.';
$lang['delete_backups_older_then']                       = 'Apagar automaticamente os backups anteriores e X dias (definir 0 para desativar)';

